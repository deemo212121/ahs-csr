'use client';

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Mic, MicOff, PhoneOff, Radio, ShieldCheck, Volume2, Wifi, WifiOff } from 'lucide-react';
import { useAuth } from '@/components/AuthProvider';
import { fetchJsonWithFirebase } from '@/lib/auth/client';
import type { CallQueueItem, CallSignal, CallSignalType, IceServersResponse } from '@/lib/calls/types';

type WebRtcCallRoomProps = {
  call: CallQueueItem;
  participantRole: 'customer' | 'staff';
  onCallEnded?: () => void;
};

type SignalResponse = { signals: CallSignal[] };

function formatDuration(seconds: number) {
  const mins = Math.floor(seconds / 60).toString().padStart(2, '0');
  const secs = Math.floor(seconds % 60).toString().padStart(2, '0');
  return `${mins}:${secs}`;
}

function recordingLabel(status: 'off' | 'recording' | 'saving' | 'saved' | 'failed') {
  if (status === 'recording') return 'Recording';
  if (status === 'saving') return 'Saving recording';
  if (status === 'saved') return 'Recording saved';
  if (status === 'failed') return 'Recording failed';
  return 'Recording starts after connection';
}

function isDescription(value: unknown): value is RTCSessionDescriptionInit {
  return Boolean(value && typeof value === 'object' && 'type' in value && 'sdp' in value);
}

function isIceCandidate(value: unknown): value is RTCIceCandidateInit {
  return Boolean(value && typeof value === 'object' && 'candidate' in value);
}

function normalizeTimestamp(value: string | null | undefined) {
  if (!value) return null;
  const trimmed = value.trim();
  const fixedTimezone = trimmed.replace(
    /(\d|\.\d+)\s+([+-]?\d{2}:?\d{2})$/,
    (_match, prefix: string, timezone: string) => `${prefix}${timezone.startsWith('-') || timezone.startsWith('+') ? timezone : `+${timezone}`}`,
  );
  const parsed = new Date(fixedTimezone);
  if (!Number.isFinite(parsed.getTime())) return null;
  return parsed.toISOString();
}

function signalBaseline(call: CallQueueItem) {
  const source = call.accepted_at || call.updated_at || new Date().toISOString();
  const normalizedSource = normalizeTimestamp(source) ?? source;
  const time = new Date(normalizedSource).getTime();
  if (!Number.isFinite(time)) return new Date(Date.now() - 10000).toISOString();
  return new Date(time - 30000).toISOString();
}

export function WebRtcCallRoom({ call, participantRole, onCallEnded }: WebRtcCallRoomProps) {
  const { user } = useAuth();
  const pcRef = useRef<RTCPeerConnection | null>(null);
  const localStreamRef = useRef<MediaStream | null>(null);
  const remoteStreamRef = useRef<MediaStream | null>(null);
  const remoteAudioRef = useRef<HTMLAudioElement | null>(null);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const recordingChunksRef = useRef<Blob[]>([]);
  const recordingContextRef = useRef<AudioContext | null>(null);
  const recordingNodesRef = useRef<MediaStreamAudioSourceNode[]>([]);
  const processedSignalsRef = useRef<Set<string>>(new Set());
  const pendingCandidatesRef = useRef<RTCIceCandidateInit[]>([]);
  const lastSignalAtRef = useRef<string>(new Date(Date.now() - 3000).toISOString());
  const offerSentRef = useRef(false);
  const readySentRef = useRef(false);
  const startSentRef = useRef(false);
  const [status, setStatus] = useState('Preparing secure audio room...');
  const [connectionState, setConnectionState] = useState<RTCPeerConnectionState>('new');
  const [muted, setMuted] = useState(false);
  const [roomError, setRoomError] = useState<string | null>(null);
  const [recordingStatus, setRecordingStatus] = useState<'off' | 'recording' | 'saving' | 'saved' | 'failed'>('off');
  const [turnConfigured, setTurnConfigured] = useState<boolean | null>(null);
  const [elapsed, setElapsed] = useState(0);

  const canJoin = call.status === 'accepted' || call.status === 'assigned';
  const roleLabel = participantRole === 'customer' ? 'Customer' : 'Staff';
  const signalSessionId = useMemo(
    () => `${call.id}:${call.accepted_at || call.updated_at || call.queued_at}`,
    [call.accepted_at, call.id, call.queued_at, call.updated_at],
  );

  const roomSubtitle = useMemo(() => {
    const branch = call.branch ? `${call.branch} branch` : 'unassigned branch';
    const request = call.request_number ? `Request ${call.request_number}` : 'Live support call';
    return `${request} • ${branch}`;
  }, [call.branch, call.request_number]);

  const postSignal = useCallback(
    async (type: CallSignalType, payload: Record<string, unknown> = {}) => {
      if (!user) return;
      await fetchJsonWithFirebase(user, `/api/calls/${call.id}/signals`, {
        method: 'POST',
        body: JSON.stringify({ type, payload: { ...payload, sessionId: signalSessionId } }),
      });
    },
    [call.id, signalSessionId, user],
  );

  const patchCall = useCallback(
    async (action: 'start' | 'end' | 'heartbeat', reason?: string) => {
      if (!user) return;
      await fetchJsonWithFirebase(user, `/api/calls/${call.id}`, {
        method: 'PATCH',
        body: JSON.stringify({ action, reason }),
      });
    },
    [call.id, user],
  );

  const uploadRecording = useCallback(
    async (blob: Blob) => {
      if (!user || participantRole !== 'staff' || !blob.size) return;

      setRecordingStatus('saving');
      try {
        const token = await user.getIdToken();
        const formData = new FormData();
        const extension = blob.type.includes('ogg') ? 'ogg' : 'webm';
        formData.append('recording', blob, `call-${call.id}.${extension}`);

        const response = await fetch(`/api/calls/${call.id}/recording`, {
          method: 'POST',
          headers: { Authorization: `Bearer ${token}` },
          body: formData,
        });
        const data = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(data.message || 'Recording upload failed.');
        setRecordingStatus('saved');
      } catch (error) {
        setRecordingStatus('failed');
        setRoomError(error instanceof Error ? error.message : 'Unable to save call recording.');
      }
    },
    [call.id, participantRole, user],
  );

  const stopRecording = useCallback(() => {
    const recorder = recorderRef.current;
    if (recorder && recorder.state !== 'inactive') {
      setRecordingStatus('saving');
      recorder.stop();
    }

    recordingNodesRef.current.forEach((node) => {
      try {
        node.disconnect();
      } catch {
        // no-op
      }
    });
    recordingNodesRef.current = [];
    void recordingContextRef.current?.close().catch(() => undefined);
    recordingContextRef.current = null;
  }, []);

  const tryStartRecording = useCallback(() => {
    if (participantRole !== 'staff') return;
    if (recorderRef.current && recorderRef.current.state !== 'inactive') return;

    const localStream = localStreamRef.current;
    const remoteStream = remoteStreamRef.current;
    if (!localStream || !remoteStream) return;

    try {
      const AudioContextCtor = window.AudioContext || (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!AudioContextCtor || typeof MediaRecorder === 'undefined') return;

      const audioContext = new AudioContextCtor();
      const destination = audioContext.createMediaStreamDestination();
      const localSource = audioContext.createMediaStreamSource(localStream);
      const remoteSource = audioContext.createMediaStreamSource(remoteStream);
      localSource.connect(destination);
      remoteSource.connect(destination);

      recordingContextRef.current = audioContext;
      recordingNodesRef.current = [localSource, remoteSource];
      recordingChunksRef.current = [];

      const preferredMime = MediaRecorder.isTypeSupported('audio/webm;codecs=opus')
        ? 'audio/webm;codecs=opus'
        : MediaRecorder.isTypeSupported('audio/webm')
          ? 'audio/webm'
          : '';

      const recorder = new MediaRecorder(destination.stream, preferredMime ? { mimeType: preferredMime } : undefined);
      recorderRef.current = recorder;
      recorder.ondataavailable = (event) => {
        if (event.data.size > 0) recordingChunksRef.current.push(event.data);
      };
      recorder.onstop = () => {
        const blob = new Blob(recordingChunksRef.current, { type: recorder.mimeType || preferredMime || 'audio/webm' });
        recordingChunksRef.current = [];
        void uploadRecording(blob);
      };
      recorder.start(1000);
      setRecordingStatus('recording');
    } catch (error) {
      setRecordingStatus('failed');
      setRoomError(error instanceof Error ? error.message : 'Unable to start call recording.');
    }
  }, [participantRole, uploadRecording]);

  const cleanup = useCallback(() => {
    stopRecording();
    pcRef.current?.getSenders().forEach((sender) => {
      try {
        sender.track?.stop();
      } catch {
        // no-op
      }
    });
    pcRef.current?.close();
    pcRef.current = null;
    localStreamRef.current?.getTracks().forEach((track) => track.stop());
    localStreamRef.current = null;
    remoteStreamRef.current = null;
    pendingCandidatesRef.current = [];
  }, [stopRecording]);

  const endCall = useCallback(
    async (reason = 'Call ended by participant.') => {
      setStatus('Ending call...');
      try {
        await postSignal('hangup', { reason });
        await patchCall('end', reason);
      } catch (error) {
        setRoomError(error instanceof Error ? error.message : 'Unable to end the call cleanly.');
      } finally {
        cleanup();
        setConnectionState('closed');
        setStatus('Call ended.');
        onCallEnded?.();
      }
    },
    [cleanup, onCallEnded, patchCall, postSignal],
  );

  useEffect(() => {
    if (!canJoin || !user) return;

    const activeUser = user;
    let cancelled = false;
    let signalTimer: number | null = null;
    let heartbeatTimer: number | null = null;
    lastSignalAtRef.current = signalBaseline(call);
    processedSignalsRef.current = new Set();
    pendingCandidatesRef.current = [];
    offerSentRef.current = false;
    readySentRef.current = false;
    startSentRef.current = false;

    async function flushPendingCandidates() {
      const peer = pcRef.current;
      if (!peer?.remoteDescription) return;
      const pending = pendingCandidatesRef.current.splice(0);
      for (const candidate of pending) {
        try {
          await peer.addIceCandidate(candidate);
        } catch {
          // Candidate can become stale after ICE restart; ignore and keep the room alive.
        }
      }
    }

    async function ensurePeer() {
      if (pcRef.current) return pcRef.current;

      setStatus('Opening microphone...');
      const ice = await fetchJsonWithFirebase<IceServersResponse>(activeUser, '/api/calls/ice');
      if (cancelled) throw new Error('cancelled');
      setTurnConfigured(ice.configured);

      const peer = new RTCPeerConnection({ iceServers: ice.iceServers });
      pcRef.current = peer;

      peer.onicecandidate = (event) => {
        if (!event.candidate) return;
        void postSignal('ice-candidate', { candidate: event.candidate.toJSON() });
      };

      peer.ontrack = (event) => {
        const [stream] = event.streams;
        if (remoteAudioRef.current && stream) {
          remoteStreamRef.current = stream;
          remoteAudioRef.current.srcObject = stream;
          void remoteAudioRef.current.play().catch(() => undefined);
          tryStartRecording();
        }
      };

      peer.onconnectionstatechange = () => {
        setConnectionState(peer.connectionState);
        if (peer.connectionState === 'connected') {
          setStatus('Connected — live audio is running.');
          tryStartRecording();
          if (!startSentRef.current) {
            startSentRef.current = true;
            void patchCall('start');
          }
        }
        if (peer.connectionState === 'failed' || peer.connectionState === 'disconnected') {
          setStatus('Connection is unstable. Reconnecting if possible...');
        }
      };

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
      if (cancelled || peer.signalingState === 'closed') {
        stream.getTracks().forEach((track) => track.stop());
        throw new Error('cancelled');
      }
      localStreamRef.current = stream;
      stream.getAudioTracks().forEach((track) => {
        if (!cancelled && peer.signalingState !== 'closed') {
          peer.addTrack(track, stream);
        }
      });
      setStatus(participantRole === 'staff' ? 'Waiting for customer audio...' : 'Waiting for staff to answer...');
      tryStartRecording();

      if (participantRole === 'staff' && !readySentRef.current) {
        readySentRef.current = true;
        await postSignal('ready', { room: call.room_name || call.id });
      }

      return peer;
    }

    async function sendOffer() {
      if (participantRole !== 'customer' || offerSentRef.current) return;
      const peer = await ensurePeer();
      if (cancelled || peer.signalingState !== 'stable') return;
      setStatus('Calling support...');
      const offer = await peer.createOffer({
        offerToReceiveAudio: true,
        offerToReceiveVideo: false,
      });
      await peer.setLocalDescription(offer);
      offerSentRef.current = true;
      await postSignal('offer', { description: peer.localDescription?.toJSON() ?? offer });
    }

    async function handleSignal(signal: CallSignal) {
      if (processedSignalsRef.current.has(signal.id)) return;
      processedSignalsRef.current.add(signal.id);
      const signalCreatedAt = normalizeTimestamp(signal.created_at);
      if (signalCreatedAt && signalCreatedAt > lastSignalAtRef.current) {
        lastSignalAtRef.current = signalCreatedAt;
      }
      if (signal.payload.sessionId !== signalSessionId) return;
      if (signal.sender_role === participantRole) return;
      if (cancelled) return;

      const peer = await ensurePeer();
      if (peer.signalingState === 'closed') return;

      if (signal.signal_type === 'ready' && participantRole === 'customer') {
        await sendOffer();
      }

      if (signal.signal_type === 'offer') {
        if (participantRole !== 'staff') return;
        if (peer.signalingState !== 'stable') return;
        const description = signal.payload.description;
        if (!isDescription(description)) return;
        setStatus('Customer is calling — connecting audio...');
        await peer.setRemoteDescription(description);
        await flushPendingCandidates();
        const answer = await peer.createAnswer();
        await peer.setLocalDescription(answer);
        await postSignal('answer', { description: peer.localDescription?.toJSON() ?? answer });
      }

      if (signal.signal_type === 'answer') {
        if (participantRole !== 'customer') return;
        if (peer.signalingState !== 'have-local-offer') return;
        const description = signal.payload.description;
        if (!isDescription(description)) return;
        await peer.setRemoteDescription(description);
        await flushPendingCandidates();
        setStatus('Audio handshake complete. Connecting...');
      }

      if (signal.signal_type === 'ice-candidate') {
        const candidate = signal.payload.candidate;
        if (!isIceCandidate(candidate)) return;
        if (peer.remoteDescription) {
          await peer.addIceCandidate(candidate).catch(() => undefined);
        } else {
          pendingCandidatesRef.current.push(candidate);
        }
      }

      if (signal.signal_type === 'hangup') {
        stopRecording();
        cleanup();
        setConnectionState('closed');
        setStatus('The other participant ended the call.');
        onCallEnded?.();
      }
    }

    async function pollSignals() {
      try {
        if (cancelled || pcRef.current?.signalingState === 'closed') return;
        const after = encodeURIComponent(lastSignalAtRef.current);
        const data = await fetchJsonWithFirebase<SignalResponse>(activeUser, `/api/calls/${call.id}/signals?after=${after}`);
        for (const signal of data.signals) {
          if (cancelled) return;
          await handleSignal(signal);
        }
      } catch (error) {
        if (cancelled || (error instanceof Error && error.message === 'cancelled')) return;
        setRoomError(error instanceof Error ? error.message : 'Unable to exchange WebRTC signals.');
      }
    }

    async function start() {
      try {
        await ensurePeer();
        await patchCall('heartbeat');
        await pollSignals();
        signalTimer = window.setInterval(() => void pollSignals(), 3000);
        heartbeatTimer = window.setInterval(() => void patchCall('heartbeat'), 20000);
      } catch (error) {
        if (cancelled || (error instanceof Error && error.message === 'cancelled')) return;
        setRoomError(error instanceof Error ? error.message : 'Unable to start the call room.');
        setStatus('Call room failed to start.');
      }
    }

    void start();

    return () => {
      cancelled = true;
      if (signalTimer) window.clearInterval(signalTimer);
      if (heartbeatTimer) window.clearInterval(heartbeatTimer);
      cleanup();
    };
  }, [
    call.accepted_at,
    call.id,
    call.queued_at,
    call.room_name,
    call.updated_at,
    canJoin,
    cleanup,
    onCallEnded,
    participantRole,
    patchCall,
    postSignal,
    signalSessionId,
    stopRecording,
    tryStartRecording,
    user,
  ]);

  useEffect(() => {
    if (connectionState !== 'connected') return;
    const timer = window.setInterval(() => setElapsed((value) => value + 1), 1000);
    return () => window.clearInterval(timer);
  }, [connectionState]);

  function toggleMute() {
    const nextMuted = !muted;
    localStreamRef.current?.getAudioTracks().forEach((track) => {
      track.enabled = !nextMuted;
    });
    setMuted(nextMuted);
  }

  if (!canJoin) {
    return (
      <div className="webrtc-room-card waiting">
        <div className="webrtc-orb"><Radio size={24} /></div>
        <div>
          <h3>Waiting for an available staff member</h3>
          <p>{roomSubtitle}</p>
        </div>
      </div>
    );
  }

  return (
    <section className="webrtc-room-card">
      <div className="webrtc-room-top">
        <div>
          <span className="call-eyebrow"><ShieldCheck size={14} /> Secure WebRTC audio</span>
          <h3>{participantRole === 'customer' ? 'Support call room' : `Live call with ${call.customer_name}`}</h3>
          <p>{roomSubtitle}</p>
        </div>
        <div className={`webrtc-state ${connectionState}`}>
          {connectionState === 'connected' ? <Wifi size={16} /> : <WifiOff size={16} />}
          {connectionState}
        </div>
      </div>

      <div className="webrtc-call-stage">
        <div className="webrtc-avatar-ring">
          <span>{participantRole === 'customer' ? 'US' : (call.customer_name || 'CX').slice(0, 2).toUpperCase()}</span>
        </div>
        <div className="webrtc-status-copy">
          <strong>{status}</strong>
          <small>
            {roleLabel} side • {turnConfigured === false ? 'STUN fallback only' : 'Metered TURN ready'} • {formatDuration(elapsed)}
            {participantRole === 'staff' ? ` • ${recordingLabel(recordingStatus)}` : ''}
          </small>
        </div>
      </div>

      {roomError ? <div className="call-room-alert">{roomError}</div> : null}

      <audio ref={remoteAudioRef} autoPlay playsInline />

      <div className="webrtc-controls">
        <button className={`webrtc-control ${muted ? 'muted' : ''}`} onClick={toggleMute} type="button">
          {muted ? <MicOff size={18} /> : <Mic size={18} />}
          {muted ? 'Unmute' : 'Mute'}
        </button>
        <button className="webrtc-control listen" type="button" onClick={() => remoteAudioRef.current?.play().catch(() => undefined)}>
          <Volume2 size={18} />
          Speaker
        </button>
        <button className="webrtc-control danger" onClick={() => void endCall()} type="button">
          <PhoneOff size={18} />
          End Call
        </button>
      </div>
    </section>
  );
}
